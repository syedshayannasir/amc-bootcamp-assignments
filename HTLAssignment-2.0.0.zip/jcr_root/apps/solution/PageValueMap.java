package apps.solution;

import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.scripting.sightly.pojo.Use;

import javax.script.Bindings;

// Helper Java code for fetching the ValueMap proeprties, that are later used for coloring background in ques4

public class PageValueMap implements Use {

    private ValueMap page1;
    private ValueMap page2;

    @Override
    public void init(Bindings bindings) {

        ResourceResolver resourceResolver = (ResourceResolver) bindings.get("resolver");

        page1 = resourceResolver.getResource("/content/my-options/option1").getValueMap();
        page2 = resourceResolver.getResource("/content/my-options/option2").getValueMap();

    }

    public ValueMap getPage1() {
        return page1;
    }

    public ValueMap getPage2() {
        return page2;
    }
}
