package com.ttn.bootcamp.components;

import com.ttn.bootcamp.interfaces.BlogsCollector;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;

@Component
public class Consumer {

    @Reference
    BlogsCollector blogsCollector;
}
