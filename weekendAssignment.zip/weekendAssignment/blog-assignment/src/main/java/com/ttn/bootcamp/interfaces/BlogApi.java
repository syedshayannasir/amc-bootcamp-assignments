package com.ttn.bootcamp.interfaces;

public interface BlogApi {

    String getBlogCategory();
    Integer getRank();
}
