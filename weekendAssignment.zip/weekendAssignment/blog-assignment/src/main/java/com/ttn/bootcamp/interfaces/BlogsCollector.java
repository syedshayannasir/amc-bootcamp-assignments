package com.ttn.bootcamp.interfaces;

public interface BlogsCollector {
}
